<?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="row" >
  <table class="table table-striped table-hover " align="middle" >
    <legend> Test  </legend>
    <?php if(session('info')): ?>
    <div class="alert alert-success " >
      <?php echo e(session('info')); ?>

    </div>
    <?php endif; ?>
    <thead>
      <tr class="bg-primary text-white" >
        <th>#</th>
        <th>Name</th>
        <th>Email</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $i = 1 ?>
      <?php if(count($articles) > 0): ?>
      <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr class="info" >
        <td><?php echo e($i++); ?></td>
        <td><?php echo e($article->name); ?></td>
        <td><?php echo e($article->email); ?></td>
        <td>
          <a href="<?php echo e(url("/update/{$article->id}")); ?>" class="btn btn-info">Update </a>  |
          <a href="<?php echo e(url("/delete/{$article->id}")); ?>" class="btn btn-danger">Delete</a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </tbody>
  </table>
</div>
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>