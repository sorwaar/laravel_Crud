<?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    <div class="row" >
        <div class="col-md-6">
            <form class="form-horizontal" method="POST" action="<?php echo e(url('/edit',array($articles->id ))); ?>" >
            	<?php echo e(csrf_field()); ?>

              <fieldset>
                <legend> Test  </legend>
                <div class="form-group">
                  <label for="inputName" class="col-lg-2 control-label">Name</label>
                  <div class="col-lg-10">
                    <input type="text" class="form-control" name="name" value="<?php echo e($articles->name); ?>" id="inputName" placeholder="Name" >
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputEmail" class="col-lg-2 control-label">Email</label>
                  <div class="col-lg-10">
                    <input type="text" class="form-control" name="email" value="<?php echo e($articles->email); ?>" id="inputEmail" placeholder="Email">
                  </div>
                </div>
                <div class="form-group">
                  <div class="col-lg-10 col-lg-offset-2">
                    <a href="<?php echo e(url('/')); ?>" type="reset" class="btn btn-default">Back</a>
                    <button type="submit" class="btn btn-primary">Update</button>
                  </div>
                </div>
              </fieldset>
            </form>            
        </div>
    </div>

<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>