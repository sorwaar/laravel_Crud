			<div class="row">
				<footer id="footer" class="text text-center " >
					
					<p>Copyright &copy 2017 Sorwar Hossain  </p>
					
				</footer>
			</div>
		</div>
	</body>
</html>